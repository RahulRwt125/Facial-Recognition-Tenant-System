import sys
import tkinter as tk
root = tk.Tk()
root.configure(background="#f3f772")
root.title("Facial Recognition System")
root.geometry("800x800")


frame = tk.Frame(root, bg = "#42c2f5")
frame.place(relx = 0, rely = 0.1, relwidth = 1, relheight = 0.8)


def IDinp():
	import tkinter as tk
	IDin = tk.Tk()
	IDin.title("Register")
	
	def inp():
		global name
		global wordname
		name = inpent.get() 
		IDin.destroy()
		savdta()
		
		
	
	
	inplab = tk.Label(IDin,text="Enter System ID")
	inpent = tk.Entry(IDin)
	inpgo = tk.Button(IDin, text="Register Face",command=inp)
	inplab.grid(row=0,column=0)
	inpent.grid(row=0,column=2)
	inpgo.grid(row=1,column=1)
	
	IDin.mainloop()	

def savdta():
	import cv2
	
	fd=cv2.CascadeClassifier(r"C:\Users\Rahul\Desktop\Facial Recognition\Reference Cascades\haarcascades\haarcascade_frontalface_default.xml")
	a = cv2.VideoCapture(0)
	#name=int(input("Enter your Number: "))
	r=0
	while True:
		z, b = a.read()
		if z == True:
			b = cv2.flip(b,1)
		g=cv2.cvtColor(b,cv2.COLOR_BGR2GRAY)
		face=fd.detectMultiScale(g,2,5)
		for(x,y,w,h) in face:
			r=r+1
			cv2.imwrite(r"C:\Users\Rahul\Desktop\Facial Recognition\Data\Face."+str(name)+"."+str(r)+'.jpg',g[y:y+h,x:x+w])
			cv2.rectangle(b,(x,y),(x+w,y+h),(0,255,0),2)
			cv2.waitKey(100)
		cv2.imshow("LOOK INTO THE CAMERA PLEASE!!",b)
		cv2.waitKey(1)
		if r==25:	
			break
		if cv2.waitKey(1) & 0xFF ==ord("q"):
			break
	cv2.destroyAllWindows()
	a.release()
	
	
	
	import cv2
	import os
	import numpy as np
	from PIL import Image
	
	recognizer = cv2.face.LBPHFaceRecognizer_create()
	path = r"C:\Users\Rahul\Desktop\Facial Recognition\Data"
	
	def img_ids(path):
		ImgPaths = [os.path.join(path,f) for f in os.listdir(path)]
		faces=[]
		IDs=[]
		names=[]
		for ImgPath in ImgPaths:
			face_Img = Image.open(ImgPath).convert("L")
			face_ar = np.array(face_Img,'uint8')  
			ID = os.path.split(ImgPath)[-1].split(".")[1]
			ID = int(ID)
			faces.append(face_ar)
			IDs.append(ID)
			names.append(name)
			cv2.waitKey(10)
		return np.array(IDs), faces	
	IDs,faces = img_ids(path)
	recognizer.train(faces, np.array(IDs))		
	recognizer.save(r"C:\Users\Rahul\Desktop\Facial Recognition\Trained Recognizer\DATA.yml")
	cv2.destroyAllWindows()


def rcgnz():
	import cv2
	fd=cv2.CascadeClassifier(r"C:\Users\Rahul\Desktop\Facial Recognition\Reference Cascades\haarcascades\haarcascade_frontalface_default.xml")
	a = cv2.VideoCapture(0)
	tre = cv2.face.LBPHFaceRecognizer_create()
	tre.read(r"C:\Users\Rahul\Desktop\Facial Recognition\Trained Recognizer\DATA.yml")
	ID = 0
	font = cv2.FONT_HERSHEY_SIMPLEX
	while True:
		z, b = a.read()
		if z == True:
			b = cv2.flip(b,1)
		g=cv2.cvtColor(b,cv2.COLOR_BGR2GRAY)
		face=fd.detectMultiScale(g,2,5)
		cv2.putText(b,"Press 'Q' to quit",(20,460),font,1,(255,255,0),2)
		for(x,y,w,h) in face:
			cv2.rectangle(b,(x,y),(x+w,y+h),(0,255,0),2)
			ID,conf = tre.predict(g[y:y+h,x:x+w])
			if conf>50:
				ID = "Authentication error"
			else:	
				if ID == 512:
					ID = "Rahul"
				elif ID == 96:
					ID = "Pooja"
				elif ID == 2700:
					ID = "Lakshay"
				else:
					ID = "Authentication error"	
			cv2.putText(b,str(ID),(x+5,y+h-7),font,1,(0,0,255),3)
		cv2.imshow("Facial Recognition IN ACTION",b)
		if cv2.waitKey(1) & 0xFF == ord("q"):
			break
	cv2.destroyAllWindows()
	a.release()

def clswndw():
	root.destroy()
	sys.exit()
	
	
but1=tk.Button(frame,padx=5,pady=5,bg='white',fg='black',text='Register',command=IDinp,font=('helvetica 15 bold'))
but1.place(relx=0,rely=0.1,relwidth=0.5,relheight=0.8)

but2=tk.Button(frame,padx=5,pady=5,bg='white',fg='black',text='Recognize',command=rcgnz,font=('helvetica 15 bold'))
but2.place(relx=0.5,rely=0.1,relwidth=0.5,relheight=0.8)

but3=tk.Button(root,padx=5,pady=5,bg='white',fg='black',text='Quit',command=clswndw,font=('helvetica 15 bold'))
but3.place(relx=0.425,rely=0.925,relwidth=0.15,relheight=0.05)






root.mainloop()	